window.onscroll = function () {

    if (document.documentElement.scrollTop > 50) {
        document.getElementById("barremenu").style.backgroundImage = "url('megabanner.jpg')";
        document.getElementById("barremenu").style.padding = "0px 10px";
        
    }
    else {
        document.getElementById("barremenu").style.backgroundImage = "url('megabanner2.jpg')";
        document.getElementById("barremenu").style.padding = "25px 10px";
        
    }


}
