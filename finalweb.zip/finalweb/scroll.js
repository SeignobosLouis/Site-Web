window.onscroll = function () {

    if (document.documentElement.scrollTop > 50) {
        document.getElementById("barremenu").style.background = "#2A9D8F";
        document.getElementById("barremenu").style.padding = "0px 10px";
        
    }
    else {
        document.getElementById("barremenu").style.background = "#264653";
        document.getElementById("barremenu").style.padding = "25px 10px";
        
    }


}


